#include <iostream>
#include <cstdlib>
#include <windows.h>
#include <time.h>
#include <fstream>
#include <conio.h>
#include <ctime>
using namespace std;

long long x=15,y=30,napravlenie=1,bx,by;//1-left 2-down 3-right 4-up
bool fire_ch=false,izmen=true;
char field[32][32]= {' '};
void gotoxy(int x, int y) //system
{
    COORD coord;
    coord.X = x;
    coord.Y = y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}
void Logo() //done
{
    cout << R"(
   ___|                                   __ __|                   |
  |        __|    _` |  _  /   |   |         |      _` |   __ \    |  /    __|
  |       |      (   |    /    |   |         |     (   |   |   |     <   \__ \
 \____|  _|     \__,_|  ___|  \__, |        _|    \__,_|  _|  _|  _|\_\  ____/
                              ____/
    )" << '\n';
    Sleep(3000);
    system("CLS");
    cout << R"(
      _____ _
 |_   _| |__   ___    __ _  __ _ _ __ ___   ___
   | | | '_ \ / _ \  / _` |/ _` | '_ ` _ \ / _ \
   | | | | | |  __/ | (_| | (_| | | | | | |  __/
   |_| |_| |_|\___|  \__, |\__,_|_| |_| |_|\___|
                     |___/
    )" << '\n';
    Sleep(1500);
    system("CLS");
}

void SetWindow(int Width, int Height) //system
{
    _COORD coord;
    coord.X = Width;
    coord.Y = Height;

    _SMALL_RECT Rect;
    Rect.Top = 0;
    Rect.Left = 0;
    Rect.Bottom = Height - 1;
    Rect.Right = Width - 1;

    HANDLE Handle = GetStdHandle(STD_OUTPUT_HANDLE);      // Get Handle
    SetConsoleScreenBufferSize(Handle, coord);            // Set Buffer Size
    SetConsoleWindowInfo(Handle, TRUE, &Rect);            // Set Window Size
}
void generations()
{
    srand(time(0));
    for(int i=0; i<3; i++)
    {
        int long_=rand()%6+1;
        int x1=rand()%(30-long_)+1;
        int y1=rand()%30+1;
        for(int xi=x1; xi<x1+long_; xi++)
            field[y1][xi]='@';

    }
    for(int i=0; i<3; i++)
    {
        int long_=rand()%6+1;
        int y1=rand()%(30-long_)+1;
        int x1=rand()%30+1;
        for(int yi=y1; yi<y1+long_; yi++)
            field[yi][x1]='@';

    }
    long long tx=10,ty=10;
    while(field[y][x]=='@')
    {
        y=rand()%30+1;
        x=rand()%30+1;
    }
}
bool check_bullet(long long x,long long y)
{
    if(field[y][x]=='@'||field[y][x]=='#')
    {
        fire_ch=false;
        izmen=true;
        return false;
    }
    else
        return true;
}
void fire()
{
    if(fire_ch)
    {
        if(napravlenie==1)
        {
            if(check_bullet(bx-1,by))
            {
                if(field[by][bx]!='T')
                {
                    field[by][bx]=' ';
                    field[by][--bx]='B';
                }
                else
                {
                    field[by][--bx]='B';
                }
            }
            else
            {
                field[by][bx]=' ';
            }
        }
        else if(napravlenie==3)
        {
            if(check_bullet(bx+1,by))
            {
                if(field[by][bx]!='T')
                {
                    field[by][bx]=' ';
                    field[by][++bx]='B';
                }
                else
                {
                    field[by][++bx]='B';
                }
            }
            else
            {
                field[by][bx]=' ';
            }
        }
        else if(napravlenie==2)
        {
            if(check_bullet(bx,by+1))
            {
                if(field[by][bx]!='T')
                {
                    field[by][bx]=' ';
                    field[++by][bx]='B';
                }
                else
                {
                    field[++by][bx]='B';
                }
            }
            else
            {
                field[by][bx]=' ';
            }
        }
        else if(napravlenie==4)
        {
            if(check_bullet(bx,by-1))
            {
                if(field[by][bx]!='T')
                {
                    field[by][bx]=' ';
                    field[--by][bx]='B';
                }
                else
                {
                    field[--by][bx]='B';
                }
            }
            else
            {
                field[by][bx]=' ';
            }
        }
    }
}
bool check(long long x1,long long y1)
{
    if(field[y1][x1]!='#'&&field[y1][x1]!='@')
        return true;
    else
        return false;
}
void map_()
{
    system("CLS");
    for(int i=0; i<32; i++)
    {
        for(int xi=0; xi<32; xi++)
            cout<<field[i][xi];
        cout<<endl;
    }
    long long k=clock()/10;
           int h, m;
            h = k / 3600;
            k %= 3600;
            m = k / 60;
            k %= 60;
    cout<<endl<<"Time:\n"<<h<<':';
    cout<<m<<':'<<k%60;

}
void peremeschenie()
{
    while(1)
    {
        fire();
        if (_kbhit())
        {
            char k=_getch();
            if(k=='w')
            {
                if(check(x,y-1))
                {
                    field[y][x]=' ';
                    field[--y][x]='T';
                    if(izmen)
                    {
                        izmen=false;
                        napravlenie=4;
                    }
                }
                map_();
            }
            else if(k=='a')
            {
                if(check(x-1,y))
                {
                    field[y][x]=' ';
                    field[y][--x]='T';
                    if(izmen)
                    {
                        izmen=false;
                        napravlenie=1;
                    }
                }
                map_();
            }
            else if(k=='s')
            {
                if(check(x,y+1))
                {
                    field[y][x]=' ';
                    field[++y][x]='T';
                    if(izmen)
                    {
                        izmen=false;
                        napravlenie=2;
                    }
                }
                map_();
            }
            else if(k=='d')
            {
                if(check(x+1,y))
                {
                    field[y][x]=' ';
                    field[y][++x]='T';
                    if(izmen)
                    {
                        izmen=false;
                        napravlenie=3;
                    }
                }
                map_();
            }
            else if(k==char(32))
            {
                fire_ch=true;
                bx=x;
                by=y;
                fire();
            }
        }
        else
            map_();
    }
}
void menu()
{
    char c='0';
    int wybrane=2;
    bool wyjscie=false;
    bool wGrze = false;
    system("CLS");
    while ((wGrze==false) && (wyjscie==false))
    {
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),11);
        gotoxy(55,16);
        cout<<char(24);
        gotoxy(55,17);
        cout<<"W";

        gotoxy(55,28);
        cout<<char(25);
        gotoxy(55,27);
        cout<<"S";

        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),15);
        gotoxy(52,19);
        cout<<" START ";
        gotoxy(52,21);
        cout<<"OPTIONS";
        gotoxy(52,23);
        cout<<" ABOUT  ";
        gotoxy(52,25);
        cout<<" QUIT  ";
        while (c!=char(13)) //10 - ������ �����, � 13 - ������� �������.
        {
            SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),10);
            gotoxy(49,19+wybrane);
            cout<<"->";
            gotoxy(60,19+wybrane);
            cout<<"<-";
            gotoxy(0,0);
            c=getch();
            gotoxy(49,19+wybrane);
            cout<<"  ";
            gotoxy(60,19+wybrane);
            cout<<"  ";
            if (c=='s')
            {
                if (wybrane<6)
                {
                    wybrane+=2;
                }
            }
            if (c=='w')
            {
                if (wybrane>0)
                {
                    wybrane-=2;
                }
            }
        }
        if (wybrane==0)
        {
            system("CLS");
            wGrze=true;  //game
            map_();
            peremeschenie();
        }
        if (wybrane==2)
        {
            //   options_menu(); //options
        }
        if (wybrane==4)
        {
        }
        if (wybrane==6)
        {
        }
        wybrane=2;
        c=' ';
        system("CLS");
    }
}




int main()
{
    for(int i=0; i<32; i++)
    {
        field[i][0]='#';
        field[i][31]='#';
        field[0][i]='#';
        field[31][i]='#';
    }
    generations();
    field[y][x]='T';
    SetWindow(113,44);
    Logo();
    menu();
    return 0;
}


